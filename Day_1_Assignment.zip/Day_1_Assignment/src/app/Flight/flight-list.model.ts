export interface Flight{
    name: string;
    number: number;
    from: string;
    to: string;
    dtime: string;
    status: any;
}