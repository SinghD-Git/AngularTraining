import { Component } from '@angular/core';
import { Flight } from '../flight-list.model';

@Component({
  selector: 'app-flight-list',
  templateUrl: './flight-list.component.html',
  styleUrl: './flight-list.component.css'
})
export class FlightListComponent {
  notavailable: string='notavailable';

  product: Flight[]= [
    {
     name : 'Indigo',
     number : 62035,
     from : 'Delhi',
     to: 'Bangalore',
     dtime : '8 AM',
     status : 'On-Time'
   },
   {
    name : 'AirIndia',
    number : 62035,
    from : 'Delhi',
    to: 'Pune',
    dtime : '',
    status : ''
  },
  {
    name : 'SpiceJet',
    number: 62035,
    from : 'Mumbai',
    to: 'Delhi',
    dtime: '',
    status : ''
  },
  {
    name : 'Indigo',
    number : 62035,
    from : 'Delhi',
    to: 'Bangalore',
    dtime : '8 AM',
    status : 'Delayed'
  },
  {
   name : 'GoAir',
   number : 62035,
   from : 'Delhi',
   to: 'Pune',
   dtime : '9 AM',
   status : 'Cancelled'
 },
 {
   name : 'SpiceJet',
   number: 62035,
   from : 'Mumbai',
   to: 'Delhi',
   dtime: '10 AM',
   status: 'Delayed'
 },
 {
  name : 'GoAir',
  number : 62035,
  from : 'Delhi',
  to: 'Bangalore',
  dtime : '8 AM',
  status : 'On-Time'
},
{
 name : 'AirAsia',
 number : 62035,
 from : 'Delhi',
 to: 'Pune',
 dtime : '9 AM',
 status : 'On-Time'
},
{
 name : 'AirAsia',
 number: 62035,
 from : 'Mumbai',
 to: 'Delhi',
 dtime: '10 AM',
 status : 'Delayed'
},
{
  name : 'GoAir',
  number: 62035,
  from : 'Mumbai',
  to: 'Delhi',
  dtime: '10 AM',
  status: 'Cancelled'
 }
]

applyFilter(){

  this.product = this.product.filter((product) => product.name== 'Indigo' || product.name== 'SpiceJet')

}

}
