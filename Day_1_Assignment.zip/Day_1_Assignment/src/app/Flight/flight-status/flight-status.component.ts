import { Component, Input } from '@angular/core';

@Component({
  selector: 'app-flight-status',
  templateUrl: './flight-status.component.html',
  styleUrl: './flight-status.component.css'
})
export class FlightStatusComponent {
  @Input() status: string ='';
}
