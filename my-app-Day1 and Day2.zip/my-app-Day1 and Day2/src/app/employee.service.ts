import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class EmployeeService {

  public _empList : Array<any> = [];

  constructor() {
    this._empList=[
      {
        name:'Ravi Sharma',
        city: 'Delhi'
      }
    ]
   }
   returnEmpData() : Array<any>{
    return this._empList;
   }

   addEmpData(item: any) : void{
    this._empList.push(item);
   }
}
