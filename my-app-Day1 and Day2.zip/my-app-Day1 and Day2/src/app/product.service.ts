import { Product } from "./product";

export class ProductService{

    public getProducts(){

        let products: Product[];

        products = [
            new Product(1, 'Memory Card', 500),
            new Product(2, 'Pen Drive', 300),
            new Product(3, 'Power bank', 1500)
        ]
        return products;
    }
}