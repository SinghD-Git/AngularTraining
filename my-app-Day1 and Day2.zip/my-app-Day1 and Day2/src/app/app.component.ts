import { Component } from '@angular/core';
import { Product } from './product';
import { ProductService } from './product.service';
import { EmployeeService } from './employee.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrl: './app.component.css'
})
export class AppComponent {
  title = 'my-app';

  message:string = "Angular First App"

  public model :any ={};
  public source : Array<any>;

  constructor(public service : EmployeeService) // injecting the service inside the component constructor
  {
     this.source = this.service.returnEmpData();
  }

  public submit() : void {
    if(this.validate())
    {
      this.service.addEmpData(this.model);
      this.reset();
    }
  }

  public reset(): void{
    this.model = {}
  }

  public validate() : boolean{
    let status : boolean = true;

    if(typeof(this.model.name) === "undefined")
    {
      alert("Name is required");
      status = false;
      return status;
    }
    else if(typeof(this.model.city) === "undefined")
    {
      alert("City is required");
      status = false;
      return status;
    }
    return true;
  }
}
