import { Component } from '@angular/core';
import { Product } from './product.model';

@Component({
  selector: 'app-product',
  templateUrl: './product.component.html',
  styleUrl: './product.component.css'
})
export class ProductComponent {
  
  isShow: boolean = true;
  status : 'in-stock' | 'out-of-stock' |undefined

  product: Product[]= [
   {
    id: 101,
    name : 'Wireless headphones',
    price : 100.00,
    description : 'Good quality headphone with noise cancellation',
    brand: 'Samsung',
    status : 'in-stock'
  },
  {
    id: 102,
    name : 'LED TV',
    price : 34000.00,
    description : 'Good quality Smart LED touch with 8xsurround voice',
    brand: 'Samsung',
    status : 'in-stock'
  },
  {
    id: 101,
    name : 'Microwave',
    price : 13000.00,
    description : 'Good quality microwave with energy savings',
    brand: 'LG',
    status : 'out-of-stock'
  }
]

}
